// --- CONFIG: replace with your real Supabase values ---
const SUPABASE_URL = "https://dodreqofnvzqlspatszu.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRvZHJlcW9mbnZ6cWxzcGF0c3p1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMwODU0MTAsImV4cCI6MjA4ODY2MTQxMH0.0iTbTrW94IyXs7ewclH-jLJTpWEHq2m2BUjxHB9sBms";
const TABLE_NAME = "sites";
// ------------------------------------------------------

const urlInput = document.getElementById("urlInput");
const passwordInput = document.getElementById("passwordInput");
const statusEl = document.getElementById("status");
const editor = document.getElementById("editor");
const openBtn = document.getElementById("openBtn");
const saveBtn = document.getElementById("saveBtn");

function setStatus(msg, isError = false) {
  statusEl.textContent = msg;
  statusEl.className = isError ? "error" : "ok";
}

function normalizeUrl(raw) {
  if (!raw) return "";
  return raw.trim();
}

// Basic Supabase REST helper
async function supabaseRequest(path, options = {}) {
  const url = `${SUPABASE_URL}/rest/v1/${path}`;
  const headers = {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
    "Content-Type": "application/json",
    Prefer: "return=representation",
    ...(options.headers || {})
  };

  try {
    const res = await fetch(url, { ...options, headers });
    if (!res.ok) {
      // 503 / network issues will fall here
      const text = await res.text();
      throw new Error(`Supabase error: ${res.status} ${text}`);
    }
    if (res.status === 204) return null;
    return await res.json();
  } catch (err) {
    // Treat as offline / unreachable
    throw new Error("Supabase is offline or unreachable.");
  }
}

// Load site for viewing/editing
async function openSite() {
  const url = normalizeUrl(urlInput.value);
  const password = passwordInput.value.trim();

  if (!url) {
    setStatus("Enter a Camcookie URL.", true);
    return;
  }

  if (url === "camcookie://dev") {
    setStatus("camcookie://dev cannot be edited.", true);
    return;
  }

  setStatus("Loading site...");

  try {
    const encodedUrl = encodeURIComponent(url);
    const data = await supabaseRequest(
      `${TABLE_NAME}?url=eq.${encodedUrl}&select=*`
    );

    if (!data || data.length === 0) {
      setStatus("Site does not exist. You can create it with Save / Create.");
      editor.value = "{\n  \"title\": \"New Camcookie Site\",\n  \"content\": \"Hello!\"\n}";
      return;
    }

    const site = data[0];

    if (!password || site.password !== password) {
      setStatus("Incorrect password for this site.", true);
      editor.value = "";
      return;
    }

    editor.value = typeof site.data === "string"
      ? site.data
      : JSON.stringify(site.data, null, 2);

    setStatus("Site loaded. You can edit and Save.");
  } catch (err) {
    setStatus(err.message || "Supabase is offline.", true);
  }
}

// Save or create site
async function saveSite() {
  const url = normalizeUrl(urlInput.value);
  const password = passwordInput.value.trim();
  const content = editor.value;

  if (!url) {
    setStatus("Enter a Camcookie URL.", true);
    return;
  }

  if (!password) {
    setStatus("Enter a password to create or edit.", true);
    return;
  }

  if (url === "camcookie://dev") {
    setStatus("camcookie://dev cannot be edited or created.", true);
    return;
  }

  setStatus("Saving site...");

  try {
    // Check if site exists
    const encodedUrl = encodeURIComponent(url);
    const existing = await supabaseRequest(
      `${TABLE_NAME}?url=eq.${encodedUrl}&select=*`
    );

    const body = {
      url,
      password,
      data: content
    };

    if (!existing || existing.length === 0) {
      // Insert new
      await supabaseRequest(TABLE_NAME, {
        method: "POST",
        body: JSON.stringify(body)
      });
      setStatus("Site created.");
    } else {
      const site = existing[0];

      if (site.password !== password) {
        setStatus("Incorrect password for this site.", true);
        return;
      }

      await supabaseRequest(`${TABLE_NAME}?url=eq.${encodedUrl}`, {
        method: "PATCH",
        body: JSON.stringify({ data: content })
      });
      setStatus("Site updated.");
    }
  } catch (err) {
    setStatus(err.message || "Supabase is offline.", true);
  }
}

openBtn.addEventListener("click", openSite);
saveBtn.addEventListener("click", saveSite);
